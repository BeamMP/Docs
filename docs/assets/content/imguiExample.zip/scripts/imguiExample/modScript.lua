load('imguiExample')
setExtensionUnloadMode('imguiExample', 'manual')
