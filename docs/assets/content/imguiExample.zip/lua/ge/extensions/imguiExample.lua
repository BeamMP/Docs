--imguiExample (CLIENT) by Dudekahedron, 2026

local M = {}

local logTag = "imguiExample"
local im = ui_imgui
local imguiExampleWindowOpen = im.BoolPtr(true)

local buttonPresses = 0

local function imguiExample()
	im.SetNextWindowSize(im.ImVec2(366, 100), im.Cond_FirstUseEver)
	im.Begin("Hello World, I am a window")
		im.Indent()
			im.Text("Hello World, I am text.")
			im.SameLine()
			if im.Button("The Hello World Button") then
				buttonPresses = buttonPresses + 1
			end
			if buttonPresses > 0 then
				im.Text("The Hello World Button has been pressed " .. buttonPresses .. " times!")
			else
				im.Text("The Hello World Button has not been pressed.")
			end
		im.Unindent()
	im.End()
end

local function toggleExampleImgui()
	imguiExampleWindowOpen[0] = not imguiExampleWindowOpen[0]
end

local function onUpdate(dt)
	if worldReadyState == 2 then
		if imguiExampleWindowOpen[0] == true then
			imguiExample()
		end
	end
end

local function onExtensionLoaded()
	log('W', logTag, "imguiExample LOADED")
end

local function onExtensionUnloaded()
	log('W', logTag, "imguiExample UNLOADED")
end

M.toggleExampleImgui = toggleExampleImgui

M.onUpdate = onUpdate

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded

M.dependencies = {"ui_imgui"}

M.onInit = function() setExtensionUnloadMode(M, "manual") end

return M
